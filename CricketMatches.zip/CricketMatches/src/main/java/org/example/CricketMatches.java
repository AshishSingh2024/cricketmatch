package org.example;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.json.JSONArray;
import org.json.JSONObject;

public class CricketMatches {

    public static void main(String[] args) {
        try {
            // Make API request
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://api.cuvora.com/car/partner/cricket-data"))
                    .header("apiKey", "test-creds@2320")
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
           // System.out.println("Response Body: " + response.body()); // Debug statement

            // Parse JSON response
            JSONObject responseObject = new JSONObject(response.body());
            JSONArray matches = responseObject.getJSONArray("data");

            int highestScore = 0;
            String highestScoringTeam = "";
            int matchesWith300PlusScore = 0;

            for (int i = 0; i < matches.length(); i++) {
                JSONObject match = matches.getJSONObject(i);

                // Get team scores
                String t1ScoreStr = match.optString("t1s", "0/0");
                String t2ScoreStr = match.optString("t2s", "0/0");

                int t1Score = parseScore(t1ScoreStr);
                int t2Score = parseScore(t2ScoreStr);

                // Determine highest score in an innings
                if (t1Score > highestScore) {
                    highestScore = t1Score;
                    highestScoringTeam = match.getString("t1");
                }

                if (t2Score > highestScore) {
                    highestScore = t2Score;
                    highestScoringTeam = match.getString("t2");
                }

                // Check if total score is 300+
                if (t1Score + t2Score > 300) {
                    matchesWith300PlusScore++;
                }
            }

            // Print results
            System.out.println("Highest Score: " + highestScore + " and Team Name: " + highestScoringTeam);
            System.out.println("Number Of Matches with total 300 Plus Score: " + matchesWith300PlusScore);

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    // Helper method to parse score
    private static int parseScore(String scoreStr) {
        // Split the score string at the '/' character
        String[] parts = scoreStr.split("/");
        // Get the total runs (first part of the split)
        String totalRunsStr = parts[0];
        // Parse the total runs
        return Integer.parseInt(totalRunsStr);
    }


}
